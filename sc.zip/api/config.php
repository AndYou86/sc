<?php

define('DB_DATA',  [
    'server' => 'localhost',
    'dbname' => 'sh',
    'username' => 'root',
    'password' => ''
]);

define('EMPTY_DATA', ['error' => true, 'text'=>'empty data']);